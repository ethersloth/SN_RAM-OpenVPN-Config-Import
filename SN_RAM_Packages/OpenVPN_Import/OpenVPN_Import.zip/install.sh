#!/bin/sh
# OpenVPN Import - GUI package installer
# Installs OpenVPN profile import feature into Red Lion Sixnet web GUI

# Check that this is a JBM/Sixnet unit
if [ ! -e "/etc/version" ]; then
    echo "Unit does not appear to be a JBM/Sixnet unit, exiting."
    exit 1
fi

# The only argument we are passed is the file name of the package
FILE_NAME=$1

# Make sure we can find that file before we continue
if [ ! -e "$FILE_NAME" ]; then
    echo "Cannot find package file $FILE_NAME"
    exit 2
fi

# Extract the rest of the contents of the package to /
# -d /            The destination directory for the unpacked contents
# -o              Overwrite existing files without prompting
# -x install.sh   Exclude install.sh (already unpacked by jbmupdate)
unzip -d / -o $FILE_NAME -x install.sh

# Set correct permissions on the CGI script
chmod 755 /home/httpd/jbmconfig/cgi-bin/ovpnimport.cgi
chown root:root /home/httpd/jbmconfig/cgi-bin/ovpnimport.cgi

# Add OpenVPN Import menu entry to customTabs.txt if not already present
CUSTOM_TABS="/home/httpd/jbmconfig/txt/customTabs.txt"
if [ -e "$CUSTOM_TABS" ]; then
    if ! grep -q "OpenVPN Import" "$CUSTOM_TABS"; then
        echo "OpenVPN Import, #!/ovpnimport" >> "$CUSTOM_TABS"
        logger -t "$FILE_NAME" "OpenVPN Import: menu entry added"
    else
        logger -t "$FILE_NAME" "OpenVPN Import: menu entry already present"
    fi
else
    logger -t "$FILE_NAME" "OpenVPN Import: WARNING customTabs.txt not found"
fi

# Create /etc/openvpn if it doesn't exist
if [ ! -d "/etc/openvpn" ]; then
    mkdir -p /etc/openvpn
    chmod 700 /etc/openvpn
fi

# Uncomment the line below to persist this package across firmware reflash
#cp -f $FILE_NAME /storage/sdk/install/

logger -t "$FILE_NAME" "OpenVPN Import: installation complete"

exit 0
